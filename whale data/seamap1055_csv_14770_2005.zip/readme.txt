Thank you for using OBIS-SEAMAP (http://seamap.env.duke.edu/)
You've downloaded dataset(s) from OBIS-SEAMAP.

Please observe the Terms of Use, which is included in the zipped file, 
for your use of the dataset. Most important is that you are required to
contact the data provider for permission if the use of the dataset leads to
any publication or products.

Please also go through the metadata. The metadata is written in
compliance with the FGDC metadata standards and ready to be used in ESRI ArcCatalog.
If you take a look at it with your browser, you may want to use 
the XML style sheet that presents the metadata in the same way you'll
see it on OBIS-SEAMAP.

To do this:
1. Unzip the zipped file to a folder with all the files in it.
2. Open the metadata xml file with Notepad or your favorite editor.
3. Insert the following line in the second line.

<?xml-stylesheet type="text/xsl" href="FGDC_SEAMAP.xsl" ?>

4. The first three lines of the final xml file should look like:

<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="text/xsl" href="FGDC_SEAMAP.xsl" ?>
<metadata xml:lang="en">

2011-09-09